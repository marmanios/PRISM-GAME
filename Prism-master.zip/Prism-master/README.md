# Prism
### THEME: Light & Dark

Prism is a pygame game about a boy named Dylan Park, who is left in an arcade overnight. He finds refuge in playing the arcade machines that have been left running-- but they seem to be lighting up the arcade... and maybe the path to his escape?

### Cool Features!

1 - Saving Games
    Utilizes SQL Databases to save game progress.

2 - A story!
    A unique story with a satisfying conclusion.
    
3 - Completely Original Art!
    All art was drawn by me, on my computer.
    
4 - Unique Gameplay Experiences!
    Prism is essentially 5 games in one-- each providing a completely different gaming experience from the last. This is certain to give players a sense of progression and keep the game fresh.
    
5 - Replayability!
    Prism was desgined with replayability in mind. Once completing the story, the player can go back and replay every game, in any order, and get as high as a score as they can.
    
6 - Scoreboard! 
    Utilizing the SQL Databases, all player high-scores are saved to the SCORES menu in the main screen.

7 - Even More!
    You'll experience more features upon playing Prism, like ambience, 2.5D Perspective, etc. So why not download it?
